"""Tests for v0.2 compile.py additions: annotations, rejection feedback, selective compile."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock

import pytest
from conftest import as_router

from synto.config import Config
from synto.models import RawNoteRecord, SingleArticle, WikiArticleRecord
from synto.ollama_client import OllamaClient
from synto.pipeline.compile import (
    _apply_draft_media_mode,
    _article_num_predict,
    _build_draft_annotations,
    _build_source_refs,
    _gather_sources,
    _inject_body_sections,
    _remove_dangling_open_brackets,
    _repair_bare_bracket_links,
    _repair_literal_newlines,
    _repair_malformed_embeds,
    _repair_malformed_wikilinks,
    _repair_wikilink_placeholders,
    _rewrite_citation_markers,
    _strip_draft_annotations,
    _strip_empty_wikilinks,
    _strip_placeholder_embeds,
    _strip_self_wikilinks,
    _strip_unknown_wikilinks,
    _write_concept_prompt,
    approve_drafts,
    compile_concepts,
    reject_draft,
)
from synto.state import StateDB
from synto.vault import ensure_wikilinks, sanitize_filename


def test_sanitize_obsidian_math_converts_display_math_before_link_repairs():
    from synto.markdown_math import sanitize_obsidian_math

    body = sanitize_obsidian_math("Before \\\[\nE = mc^2\n\\\] after")

    assert body == "Before $$\nE = mc^2\n$$ after"


def test_sanitize_obsidian_math_wraps_standalone_bare_latex_line():
    from synto.markdown_math import sanitize_obsidian_math

    body = sanitize_obsidian_math("\\frac{a}{b}\n")

    assert body == "$$ \\frac{a}{b} $$\n"


def test_sanitize_obsidian_math_keeps_code_and_existing_math_unchanged():
    from synto.markdown_math import sanitize_obsidian_math

    body = sanitize_obsidian_math("`\\frac{a}{b}`\n$$\nE = mc^2\n$$\n")

    assert body == "`\\frac{a}{b}`\n$$\nE = mc^2\n$$\n"


@pytest.fixture
def vault(tmp_path: Path) -> Path:
    (tmp_path / "raw").mkdir()
    (tmp_path / "wiki").mkdir()
    (tmp_path / "wiki" / ".drafts").mkdir()
    (tmp_path / ".synto").mkdir()
    return tmp_path


@pytest.fixture
def config(vault: Path) -> Config:
    return Config(vault=vault)


@pytest.fixture
def db(config: Config) -> StateDB:
    return StateDB(config.state_db_path)


def make_mock_client(response: str = "{}"):
    client = MagicMock(spec=OllamaClient)
    client.generate.return_value = response
    return as_router(client)


def test_article_num_predict_respects_config_cap(config):
    config.pipeline.article_max_tokens = 2048

    assert _article_num_predict(config, prompt="short", system="system") == 2048


def test_article_num_predict_concept_compile_applies_soft_output_cap(config, db, monkeypatch):
    config.provider = config.effective_provider.model_copy(update={"heavy_ctx": 262144})
    config.pipeline.article_max_tokens = 300000
    db.upsert_raw(RawNoteRecord(path="raw/src.md", content_hash="h1", status="ingested"))
    db.upsert_concepts("raw/src.md", ["Heavy Concept"])
    (config.vault / "raw" / "src.md").write_text(
        "---\ntitle: Source\n---\nContent about Heavy Concept.",
        encoding="utf-8",
    )

    captured: dict[str, int] = {}

    def fake_request_structured(**kwargs):
        captured["num_predict"] = kwargs["num_predict"]
        return SingleArticle(title="Heavy Concept", content="Body", tags=["heavy-concept"])

    monkeypatch.setattr(
        "synto.pipeline.compile.request_structured",
        fake_request_structured,
    )

    drafts, failed, _ = compile_concepts(config, make_mock_client(), db, concepts=["Heavy Concept"])

    assert failed == []
    assert len(drafts) == 1
    assert captured["num_predict"] == 2400


def test_article_num_predict_concept_compile_can_disable_extra_soft_cap(config, db, monkeypatch):
    config.provider = config.effective_provider.model_copy(update={"heavy_ctx": 262144})
    config.pipeline.article_max_tokens = 5000
    config.pipeline.concept_draft_soft_cap = "article_max_tokens"
    db.upsert_raw(RawNoteRecord(path="raw/src.md", content_hash="h1", status="ingested"))
    db.upsert_concepts("raw/src.md", ["Heavy Concept"])
    (config.vault / "raw" / "src.md").write_text(
        "---\ntitle: Source\n---\nContent about Heavy Concept.",
        encoding="utf-8",
    )

    captured: dict[str, int] = {}

    def fake_request_structured(**kwargs):
        captured["num_predict"] = kwargs["num_predict"]
        return SingleArticle(title="Heavy Concept", content="Body", tags=["heavy-concept"])

    monkeypatch.setattr(
        "synto.pipeline.compile.request_structured",
        fake_request_structured,
    )

    drafts, failed, _ = compile_concepts(config, make_mock_client(), db, concepts=["Heavy Concept"])

    assert failed == []
    assert len(drafts) == 1
    assert captured["num_predict"] == 5000


def test_article_num_predict_raises_when_context_too_small(config):
    """When prompt fills heavy_ctx, available output drops below the floor needed for
    reliable structured generation. Raise so the caller can mark this concept as failed
    rather than send max_tokens=0 (silent malformed behavior on some providers)."""
    config.provider = config.effective_provider.model_copy(update={"heavy_ctx": 1024})
    prompt = "x" * 3200  # ~800 prompt tokens; leaves <512 for output.

    with pytest.raises(ValueError, match="too large"):
        _article_num_predict(config, prompt=prompt, system="")


def test_article_num_predict_floors_at_min_when_math_dominates(config):
    """When math allows between the floor and user cap, return the math limit."""
    config.provider = config.effective_provider.model_copy(update={"heavy_ctx": 4096})
    config.pipeline.article_max_tokens = 16384
    prompt = "x" * 1000  # ~250 prompt tokens, leaves ~3590 available
    result = _article_num_predict(config, prompt=prompt, system="")
    assert 512 <= result <= 4096
    assert result < 16384  # capped by math, not config


# ── Annotations ───────────────────────────────────────────────────────────────


def test_build_annotations_low_confidence(db):
    annotations = _build_draft_annotations(0.3, ["raw/a.md"], db)
    assert any("low-confidence" in a for a in annotations)


def test_build_annotations_single_source(db):
    annotations = _build_draft_annotations(0.8, ["raw/a.md"], db)
    assert any("single-source" in a for a in annotations)


def test_build_no_annotations_above_threshold(db):
    rec_a = RawNoteRecord(path="raw/a.md", content_hash="h1", status="ingested", quality="high")
    rec_b = RawNoteRecord(path="raw/b.md", content_hash="h2", status="ingested", quality="high")
    db.upsert_raw(rec_a)
    db.upsert_raw(rec_b)
    annotations = _build_draft_annotations(0.75, ["raw/a.md", "raw/b.md"], db)
    # High confidence, multiple sources, high quality → no annotations
    assert annotations == []


def test_build_annotations_all_low_quality(db):
    rec_a = RawNoteRecord(path="raw/a.md", content_hash="h1", status="ingested", quality="low")
    rec_b = RawNoteRecord(path="raw/b.md", content_hash="h2", status="ingested", quality="low")
    db.upsert_raw(rec_a)
    db.upsert_raw(rec_b)
    annotations = _build_draft_annotations(0.6, ["raw/a.md", "raw/b.md"], db)
    assert any("low-quality" in a for a in annotations)


def test_build_annotations_prompt_degraded(db):
    annotations = _build_draft_annotations(0.75, ["raw/a.md", "raw/b.md"], db, prompt_degraded=True)
    assert any("prompt degraded to fit provider context" in a for a in annotations)


def test_strip_annotations_removes_synto_auto(db):
    body = "<!-- synto-auto: low-confidence -->\n\n## Overview\n\nContent."
    stripped = _strip_draft_annotations(body)
    assert "synto-auto" not in stripped
    assert "## Overview" in stripped
    assert "Content." in stripped


def test_strip_annotations_leaves_user_html_comments(db):
    body = "<!-- user comment -->\n\n<!-- synto-auto: single-source -->\n\nContent."
    stripped = _strip_draft_annotations(body)
    assert "<!-- user comment -->" in stripped
    assert "synto-auto" not in stripped


def test_strip_annotations_removes_legacy_olw_auto(db):
    body = "<!-- olw-auto: low-confidence -->\n\n## Overview\n\nContent."
    stripped = _strip_draft_annotations(body)
    assert "olw-auto" not in stripped


def test_strip_annotations_no_annotations_unchanged(db):
    body = "## Title\n\nNo annotations here."
    assert _strip_draft_annotations(body) == body


def test_inject_body_sections_always_includes_sources_heading(config):
    body = _inject_body_sections("## Overview\n\nContent.", [], config)
    assert "## Sources" in body


def test_build_source_refs_stable_order_and_metadata(vault):
    (vault / "raw" / "a.md").write_text("---\ntitle: Alpha Source\n---\nBody A.")
    (vault / "raw" / "b.md").write_text("Body B.")

    refs = _build_source_refs(["raw/a.md", "raw/b.md"], vault)

    assert [r.id for r in refs] == ["S1", "S2"]
    assert refs[0].raw_path == "raw/a.md"
    assert refs[0].title == "Alpha Source"
    assert refs[0].wiki_target == "sources/Alpha Source"
    assert refs[1].title == "B"


def test_gather_sources_with_refs_labels_source_ids(vault):
    (vault / "raw" / "a.md").write_text("---\ntitle: Alpha Source\n---\nBody A.")
    refs = _build_source_refs(["raw/a.md"], vault)

    text, resolved = _gather_sources(["raw/a.md"], vault, source_refs=refs)

    assert "## Source [S1]: Alpha Source (raw/a.md)" in text
    assert resolved == ["raw/a.md"]


def test_rewrite_citation_markers_single_and_multi(vault):
    (vault / "raw" / "a.md").write_text("---\ntitle: Alpha Source\n---\nA")
    (vault / "raw" / "b.md").write_text("---\ntitle: Beta Source\n---\nB")
    refs = _build_source_refs(["raw/a.md", "raw/b.md"], vault)

    body = _rewrite_citation_markers("Claim [S1]. Joint [S1, S2].", refs)

    assert "([[sources/Alpha Source|S1]])" in body
    assert "([[sources/Alpha Source|S1]], [[sources/Beta Source|S2]])" in body


def test_rewrite_citation_markers_legend_only_keeps_plain_ids(vault):
    (vault / "raw" / "a.md").write_text("---\ntitle: Alpha Source\n---\nA")
    (vault / "raw" / "b.md").write_text("---\ntitle: Beta Source\n---\nB")
    refs = _build_source_refs(["raw/a.md", "raw/b.md"], vault)

    body = _rewrite_citation_markers("Claim [S1]. Joint [S1, S2].", refs, link_inline=False)

    assert body == "Claim [S1](#Sources). Joint [S1,S2](#Sources)."
    assert "sources/" not in body


def test_rewrite_citation_markers_ignores_unknown_ids(vault):
    (vault / "raw" / "a.md").write_text("---\ntitle: Alpha Source\n---\nA")
    refs = _build_source_refs(["raw/a.md"], vault)

    body = _rewrite_citation_markers("Known [S1]. Unknown [S99]. Mixed [S1,S99].", refs)

    assert "Known ([[sources/Alpha Source|S1]])." in body
    assert "Unknown ." in body
    assert "Mixed ([[sources/Alpha Source|S1]])." in body


def test_rewrite_citation_markers_skips_code_embeds_and_existing_links(vault):
    (vault / "raw" / "a.md").write_text("---\ntitle: Alpha Source\n---\nA")
    refs = _build_source_refs(["raw/a.md"], vault)

    body = _rewrite_citation_markers(
        "`code [S1]`\n\n```\nblock [S1]\n```\n![[image [S1].png]] [[Existing [S1]]] prose [S1]",
        refs,
    )

    assert "`code [S1]`" in body
    assert "block [S1]" in body
    assert "![[image [S1].png]]" in body
    assert "[[Existing [S1]]]" in body
    assert "prose ([[sources/Alpha Source|S1]])" in body


def test_rewrite_citation_markers_restores_masks_after_length_changes(vault):
    (vault / "raw" / "a.md").write_text("---\ntitle: Alpha Source\n---\nA")
    refs = _build_source_refs(["raw/a.md"], vault)

    body = _rewrite_citation_markers("prose [S1] then `code [S1]` and [[Link [S1]]].", refs)

    assert body == ("prose ([[sources/Alpha Source|S1]]) then `code [S1]` and [[Link [S1]]].")


def test_repair_bare_bracket_links_converts_llm_slips():
    body = _repair_bare_bracket_links(
        "See [API] and [Product Backlog].", ["API", "Product Backlog"]
    )

    assert body == "See [[API]] and [[Product Backlog]]."


def test_repair_bare_bracket_links_skips_markdown_citations_and_masks():
    body = _repair_bare_bracket_links(
        "Claim [S1]. Link [text](https://example.com). `code [API]` [[Already]] prose [API]",
        ["API"],
    )

    assert body == (
        "Claim [S1]. Link [text](https://example.com). `code [API]` [[Already]] prose [[API]]"
    )


def test_repair_bare_bracket_links_leaves_unknown_bracketed_prose_plain():
    body = _repair_bare_bracket_links("Known [API]. Unknown [Agile Development] note.", ["API"])

    assert body == "Known [[API]]. Unknown Agile Development note."


def test_repair_literal_newlines_converts_escaped_markdown():
    body = _repair_literal_newlines("## A\\n\\nBody\\n- item")

    assert body == "## A\n\nBody\n- item"


def test_strip_unknown_wikilinks_unwraps_invented_links():
    body = _strip_unknown_wikilinks(
        "Known [[API Testing]]. Unknown [[Название статьи]]. Aliased [[Missing|display]].",
        ["API Testing"],
    )

    assert body == "Known [[API Testing]]. Unknown Название статьи. Aliased display."


def test_strip_unknown_wikilinks_keeps_source_links():
    body = _strip_unknown_wikilinks(
        "Claim ([[sources/Reference Note|S1]]) and [[sources/Foo]].",
        [],
    )

    assert body == "Claim ([[sources/Reference Note|S1]]) and [[sources/Foo]]."


def test_strip_unknown_wikilinks_keeps_embeds():
    body = _strip_unknown_wikilinks("Diagram ![[file.pdf]] and unknown [[Ghost]].", [])

    assert body == "Diagram ![[file.pdf]] and unknown Ghost."


def test_strip_self_wikilinks_unwraps_self_links():
    body = _strip_self_wikilinks("[[Scrum]] and [[Scrum|this page]] link to [[Kanban]].", "Scrum")

    assert body == "Scrum and this page link to [[Kanban]]."


def test_strip_unknown_resolves_concept_by_stem():
    # A concept titled "TCP/IP" lives at TCPIP.md. An already-resolving [[TCPIP]] is kept
    # verbatim; a raw [[TCP/IP]] (LLM-authored, non-resolving) is rewritten to the stem with
    # the raw title as display — neither is stripped.
    body = _strip_unknown_wikilinks(
        "Use [[TCPIP]] and [[TCP/IP]] and [[TCP/IP|the protocol]].",
        ["TCP/IP"],
        {"tcpip": "TCP/IP"},
    )
    assert body == "Use [[TCPIP]] and [[TCPIP|TCP/IP]] and [[TCPIP|the protocol]]."


def test_strip_unknown_without_stem_map_strips_normalized_link():
    # Documents the defect this fix addresses: without stem resolution, [[TCPIP]] is not in
    # the raw known set {"tcp/ip"} and gets unwrapped, mangling prose to "TCPIP".
    assert _strip_unknown_wikilinks("Use [[TCPIP]] here.", ["TCP/IP"]) == "Use TCPIP here."


def test_strip_unknown_leaves_normal_titles_unchanged():
    # Normal title (stem == title): no display is added, link kept verbatim.
    body = _strip_unknown_wikilinks(
        "[[API Testing]].", ["API Testing"], {"api testing": "API Testing"}
    )
    assert body == "[[API Testing]]."


def test_strip_self_wikilinks_stem_aware():
    # A self-link resolved to the stem ([[TCPIP]] for article "TCP/IP") is still unwrapped.
    body = _strip_self_wikilinks("[[TCPIP]] and [[TCP/IP|this]] vs [[Kanban]].", "TCP/IP")
    assert body == "TCPIP and this vs [[Kanban]]."


def test_pipeline_links_forbidden_char_title_end_to_end():
    # End-to-end through the link-processing order used by _write_draft: a concept titled
    # "TCP/IP" must come out as a working [[TCPIP|TCP/IP]] link whether the body mentioned
    # it in plain text or as an LLM-authored [[TCP/IP]] — and never stripped or mangled.
    existing_titles = ["TCP/IP"]
    stem_to_title = {"tcpip": "TCP/IP"}
    for raw_body in ("Networks use TCP/IP heavily.", "See [[TCP/IP]] now."):
        body = ensure_wikilinks(raw_body, existing_titles)
        body = _strip_unknown_wikilinks(body, existing_titles, stem_to_title)
        body = _strip_self_wikilinks(body, "Some Other Article")
        assert "[[TCPIP|TCP/IP]]" in body
        # The target equals the on-disk filename stem, so the link resolves in Obsidian.
        assert sanitize_filename("TCP/IP") == "TCPIP"


def test_strip_empty_wikilinks_removes_empty_targets():
    body = _strip_empty_wikilinks("Bad [[]]. Display [[|shown]]. Keep [[Kanban]].")

    assert body == "Bad . Display shown. Keep [[Kanban]]."


def test_repair_malformed_embeds_converts_bare_media_embed():
    body = _repair_malformed_embeds("Diagram !./_resources/file.pdf and ![[already.pdf]].")

    assert body == "Diagram ![[./_resources/file.pdf]] and ![[already.pdf]]."


def test_repair_malformed_embeds_converts_escaped_markdown_media_refs():
    body = _repair_malformed_embeds(
        "Images !\\[./_resources/a.jpeg\\]!\\[./_resources/b.jpeg\\!\\[./_resources/c.jpeg\\]"
    )

    assert "![[./_resources/a.jpeg]]" in body
    assert "![[./_resources/b.jpeg]]" in body
    assert "![[./_resources/c.jpeg]]" in body
    assert "!\\[" not in body


def test_remove_dangling_open_brackets():
    body = _remove_dangling_open_brackets("Check these aspects [\n\nNext paragraph.")

    assert body == "Check these aspects\n\nNext paragraph."


def test_repair_malformed_wikilinks_strips_quote_and_citation_debris():
    body = _repair_malformed_wikilinks(
        "See [[Independent publishing culture”]] and [[Documentary notes”, S2]].",
        ["Independent publishing culture", "Documentary notes"],
    )

    assert body == "See [[Independent publishing culture]] and [[Documentary notes]]."


def test_repair_wikilink_placeholders_collapses_nested_and_stray_tokens():
    body = _repair_wikilink_placeholders(
        "Bad [[wikilinks][[Agentic ROI]]] and stray [[wikilinks]LLM agents]."
    )

    assert body == "Bad [[Agentic ROI]] and stray LLM agents."


def test_apply_draft_media_mode_reference_replaces_embeds():
    body = _apply_draft_media_mode("Diagram ![[./_resources/file.pdf]].", "reference")

    assert body == "Diagram Media reference: ./_resources/file.pdf."


def test_apply_draft_media_mode_embed_keeps_embeds():
    body = _apply_draft_media_mode("Diagram ![[./_resources/file.pdf]].", "embed")

    assert body == "Diagram ![[./_resources/file.pdf]]."


def test_apply_draft_media_mode_omit_removes_embeds():
    body = _apply_draft_media_mode("Diagram ![[./_resources/file.pdf]].", "omit")

    assert body == "Diagram ."


def test_strip_placeholder_embeds_removes_unknown_filename_embeds_only():
    body = _strip_placeholder_embeds(
        "Before ![[./_resources/unknown_filename.jpeg]] keep ![[./_resources/diagram.jpeg]] after."
    )

    assert "unknown_filename" not in body
    assert "diagram.jpeg" in body


def test_gather_sources_strips_placeholder_embeds_from_raw_sources(vault):
    raw = vault / "raw" / "a.md"
    raw.parent.mkdir(parents=True, exist_ok=True)
    raw.write_text(
        "---\ntitle: A\n---\nBody before ![[./_resources/unknown_filename.jpeg]] after.",
        encoding="utf-8",
    )

    text, resolved = _gather_sources(["raw/a.md"], vault)

    assert resolved == ["raw/a.md"]
    assert "unknown_filename" not in text


def test_inject_body_sections_uses_id_legend_when_enabled(config):
    (config.vault / "raw" / "a.md").write_text("---\ntitle: Alpha Source\n---\nA")
    config.pipeline.inline_source_citations = True

    body = _inject_body_sections(
        "See [[Concept]] and [[sources/Alpha Source|S1]].", ["raw/a.md"], config
    )

    assert "- [S1] [[sources/Alpha Source|Alpha Source]]" in body
    assert "- [[Concept]]" in body
    assert "- [[sources/Alpha Source]]" not in body


def test_inject_body_sections_skips_self_link_in_see_also(config):
    body = _inject_body_sections("See [[Scrum]] and [[Kanban]].", [], config, article_title="Scrum")

    assert "- [[Kanban]]" in body
    assert "- [[Scrum]]" not in body


def test_write_concept_prompt_citation_instructions_flagged():
    prompt = _write_concept_prompt("Topic", "source", [], inline_source_citations=True)
    assert "Inline source citations" in prompt
    assert "[S1,S2]" in prompt


def test_write_concept_prompt_no_citation_instructions_by_default():
    prompt = _write_concept_prompt("Topic", "source", [])
    assert "Inline source citations" not in prompt


def test_annotations_stripped_on_approve(config, db, tmp_path):
    """Annotations must be absent in published articles."""
    import frontmatter as fm_lib

    from synto.vault import atomic_write, parse_note

    annotated_body = "<!-- synto-auto: low-confidence (0.25) -->\n\n## Overview\n\nContent."
    meta = {
        "title": "Test Article",
        "status": "draft",
        "tags": [],
        "sources": [],
        "confidence": 0.25,
        "created": "2024-01-01",
        "updated": "2024-01-01",
    }
    draft_path = config.drafts_dir / "Test_Article.md"
    atomic_write(draft_path, fm_lib.dumps(fm_lib.Post(annotated_body, **meta)))
    db.upsert_article(
        WikiArticleRecord(
            path=str(draft_path.relative_to(config.vault)),
            title="Test Article",
            sources=[],
            content_hash="h",
            status="draft",
        )
    )

    published = approve_drafts(config, db, [draft_path])
    assert len(published) == 1
    _, pub_body = parse_note(published[0])
    assert "synto-auto" not in pub_body
    assert "olw-auto" not in pub_body
    assert "## Overview" in pub_body


# ── Rejection feedback in prompt ──────────────────────────────────────────────


def test_write_concept_prompt_no_rejection_history():
    prompt = _write_concept_prompt("Quantum Computing", "source text", [])
    assert "PREVIOUS REJECTIONS" not in prompt


def test_write_concept_prompt_with_rejection_history():
    history = ["Too vague", "Wrong format"]
    prompt = _write_concept_prompt(
        "Quantum Computing", "source text", [], rejection_history=history
    )
    assert "PREVIOUS REJECTIONS" in prompt
    assert "Too vague" in prompt
    assert "Wrong format" in prompt


def test_write_concept_prompt_deduplicates_feedback():
    history = ["Same feedback", "Same feedback", "Different feedback"]
    prompt = _write_concept_prompt("Topic", "source", [], rejection_history=history)
    # Should appear only once
    assert prompt.count("Same feedback") == 1
    assert "Different feedback" in prompt


# ── reject_draft stores feedback and body ────────────────────────────────────


def test_reject_draft_stores_feedback(config, db, tmp_path):
    import frontmatter as fm_lib

    from synto.vault import atomic_write

    draft_path = config.drafts_dir / "Test.md"
    meta = {"title": "Test Topic", "status": "draft", "tags": [], "sources": [], "confidence": 0.5}
    atomic_write(draft_path, fm_lib.dumps(fm_lib.Post("Draft body.", **meta)))
    db.upsert_article(
        WikiArticleRecord(
            path=str(draft_path.relative_to(config.vault)),
            title="Test Topic",
            sources=[],
            content_hash="h",
            status="draft",
        )
    )

    reject_draft(draft_path, config, db, feedback="Needs more detail")

    assert not draft_path.exists()
    rejections = db.get_rejections("Test Topic")
    assert len(rejections) == 1
    assert rejections[0]["feedback"] == "Needs more detail"
    assert rejections[0]["body"] == "Draft body."


def test_reject_draft_no_feedback_no_rejection(config, db):
    import frontmatter as fm_lib

    from synto.vault import atomic_write

    draft_path = config.drafts_dir / "Test.md"
    meta = {"title": "Test", "status": "draft", "tags": [], "sources": [], "confidence": 0.5}
    atomic_write(draft_path, fm_lib.dumps(fm_lib.Post("body", **meta)))
    db.upsert_article(
        WikiArticleRecord(
            path=str(draft_path.relative_to(config.vault)),
            title="Test",
            sources=[],
            content_hash="h",
            status="draft",
        )
    )

    reject_draft(draft_path, config, db, feedback="")
    assert db.rejection_count("Test") == 0


def test_reject_draft_blocks_after_cap(config, db):
    """5th rejection auto-blocks the concept."""
    import frontmatter as fm_lib

    from synto.vault import atomic_write

    for i in range(4):
        db.add_rejection("Blocked Topic", f"feedback {i}", body="body")

    # 5th rejection via reject_draft
    draft_path = config.drafts_dir / "Blocked.md"
    meta = {
        "title": "Blocked Topic",
        "status": "draft",
        "tags": [],
        "sources": [],
        "confidence": 0.5,
    }  # noqa: E501
    atomic_write(draft_path, fm_lib.dumps(fm_lib.Post("body", **meta)))
    db.upsert_article(
        WikiArticleRecord(
            path=str(draft_path.relative_to(config.vault)),
            title="Blocked Topic",
            sources=[],
            content_hash="h",
            status="draft",
        )
    )

    reject_draft(draft_path, config, db, feedback="Still wrong")
    assert db.is_concept_blocked("Blocked Topic")


# ── Selective compile (concepts= param) ───────────────────────────────────────


def test_compile_concepts_selective(config, db, tmp_path):
    """compile_concepts(concepts=['Alpha']) should only compile Alpha, not Beta."""
    import json

    # Set up two concepts needing compile
    db.upsert_raw(RawNoteRecord(path="raw/a.md", content_hash="h1", status="ingested"))
    db.upsert_raw(RawNoteRecord(path="raw/b.md", content_hash="h2", status="ingested"))
    db.upsert_concepts("raw/a.md", ["Alpha"])
    db.upsert_concepts("raw/b.md", ["Beta"])

    # Write source files
    (config.vault / "raw" / "a.md").write_text("---\ntitle: A\n---\nContent about Alpha.")
    (config.vault / "raw" / "b.md").write_text("---\ntitle: B\n---\nContent about Beta.")

    mock_response = json.dumps({"title": "Alpha", "content": "Alpha content.", "tags": []})
    client = make_mock_client(mock_response)

    drafts, failed, _ = compile_concepts(config, client, db, concepts=["Alpha"])
    assert len(drafts) == 1
    assert "Alpha" in drafts[0].name or "alpha" in drafts[0].name.lower()
    # Beta should still be needing compile
    needing = db.concepts_needing_compile()
    assert "Beta" in needing


def test_compile_concepts_none_compiles_all(config, db):
    """concepts=None falls back to all needing compile."""
    import json

    db.upsert_raw(RawNoteRecord(path="raw/a.md", content_hash="h1", status="ingested"))
    db.upsert_concepts("raw/a.md", ["Topic"])
    (config.vault / "raw" / "a.md").write_text("---\ntitle: A\n---\nContent.")

    mock_response = json.dumps({"title": "Topic", "content": "Content.", "tags": []})
    client = make_mock_client(mock_response)

    drafts, failed, _ = compile_concepts(config, client, db, concepts=None)
    assert len(drafts) == 1


def test_compile_concepts_preserves_canonical_title(config, db):
    import json

    db.upsert_raw(RawNoteRecord(path="raw/a.md", content_hash="h1", status="ingested"))
    db.upsert_concepts("raw/a.md", ["Product Backlog"])
    db.upsert_aliases("Product Backlog", ["Продуктовый бэклог"])
    (config.vault / "raw" / "a.md").write_text("---\ntitle: A\n---\nContent.")

    mock_response = json.dumps({"title": "Продуктовый бэклог", "content": "Content.", "tags": []})
    client = make_mock_client(mock_response)

    drafts, failed, _ = compile_concepts(config, client, db, concepts=["Product Backlog"])

    assert failed == []
    assert len(drafts) == 1
    assert drafts[0].name == "Product Backlog.md"
    assert db.get_article("wiki/.drafts/Product Backlog.md").title == "Product Backlog"


def test_compile_concepts_preserves_existing_tags_when_model_returns_none(config, db):
    import hashlib
    import json

    db.upsert_raw(RawNoteRecord(path="raw/a.md", content_hash="h1", status="ingested"))
    db.upsert_concepts("raw/a.md", ["Template Catalog"])
    (config.vault / "raw" / "a.md").write_text("---\ntitle: A\n---\nContent.")
    existing_body = "Existing."
    existing_note = (
        "---\n"
        "title: Template Catalog\n"
        "tags: [templates, catalog]\n"
        "created: '2026-04-25'\n"
        "---\n\n"
        f"{existing_body}"
    )
    (config.wiki_dir / "Template Catalog.md").write_text(existing_note)
    db.upsert_article(
        WikiArticleRecord(
            path="wiki/Template Catalog.md",
            title="Template Catalog",
            sources=["raw/a.md"],
            content_hash=hashlib.sha256(existing_body.encode("utf-8")).hexdigest(),
            status="published",
        )
    )

    client = make_mock_client(
        json.dumps({"title": "Template Catalog", "content": "Updated content.", "tags": []})
    )

    drafts, failed, _ = compile_concepts(config, client, db, concepts=["Template Catalog"])

    assert failed == []
    assert len(drafts) == 1
    draft_text = drafts[0].read_text(encoding="utf-8")
    assert "tags:\n- templates\n- catalog" in draft_text


def test_compile_concepts_legend_only_citations_do_not_link_inline(config, db):
    import json

    config.pipeline.inline_source_citations = True
    config.pipeline.source_citation_style = "legend-only"
    db.upsert_raw(RawNoteRecord(path="raw/a.md", content_hash="h1", status="ingested"))
    db.upsert_concepts("raw/a.md", ["Alpha"])
    (config.vault / "raw" / "a.md").write_text("---\ntitle: Alpha Source\n---\nContent.")

    mock_response = json.dumps({"title": "Alpha", "content": "Claim [S1].", "tags": []})
    client = make_mock_client(mock_response)

    drafts, failed, _ = compile_concepts(config, client, db, concepts=["Alpha"])

    assert failed == []
    body = drafts[0].read_text()
    assert "Claim [S1](#Sources)." in body
    assert "Claim ([[sources/Alpha Source|S1]])." not in body
    assert "- [S1] [[sources/Alpha Source|Alpha Source]]" in body


def test_compile_concepts_draft_media_reference_mode(config, db):
    import json

    config.pipeline.draft_media = "reference"
    db.upsert_raw(RawNoteRecord(path="raw/a.md", content_hash="h1", status="ingested"))
    db.upsert_concepts("raw/a.md", ["Alpha"])
    (config.vault / "raw" / "a.md").write_text("---\ntitle: Alpha Source\n---\nContent.")

    mock_response = json.dumps(
        {"title": "Alpha", "content": "Diagram ![[./_resources/file.pdf]].", "tags": []}
    )
    client = make_mock_client(mock_response)

    drafts, failed, _ = compile_concepts(config, client, db, concepts=["Alpha"])

    assert failed == []
    body = drafts[0].read_text()
    assert "![[./_resources/file.pdf]]" not in body
    assert "Media reference: ./_resources/file.pdf" in body


def test_compile_concepts_links_to_same_batch_concepts(config, db):
    import json

    db.upsert_raw(RawNoteRecord(path="raw/a.md", content_hash="h1", status="ingested"))
    db.upsert_raw(RawNoteRecord(path="raw/b.md", content_hash="h2", status="ingested"))
    db.upsert_concepts("raw/a.md", ["Alpha"])
    db.upsert_concepts("raw/b.md", ["Beta"])
    (config.vault / "raw" / "a.md").write_text("---\ntitle: A\n---\nAlpha mentions Beta.")
    (config.vault / "raw" / "b.md").write_text("---\ntitle: B\n---\nBeta.")

    client = make_mock_client()
    client.generate.side_effect = [
        json.dumps({"title": "Alpha", "content": "Alpha relates to Beta.", "tags": []}),
        json.dumps({"title": "Beta", "content": "Beta details.", "tags": []}),
    ]

    drafts, failed, _ = compile_concepts(config, client, db)

    assert failed == []
    alpha = next(path for path in drafts if path.name == "Alpha.md")
    assert "[[Beta]]" in alpha.read_text()


def test_compile_concepts_skips_pending_draft(config, db):
    import json

    import frontmatter as fm_lib

    from synto.vault import atomic_write

    db.upsert_raw(RawNoteRecord(path="raw/a.md", content_hash="h1", status="ingested"))
    db.upsert_concepts("raw/a.md", ["Alpha"])
    (config.vault / "raw" / "a.md").write_text("---\ntitle: A\n---\nContent.")
    draft_path = config.drafts_dir / "Alpha.md"
    atomic_write(
        draft_path,
        fm_lib.dumps(
            fm_lib.Post("User-reviewed draft body.", title="Alpha", tags=[], status="draft")
        ),
    )

    mock_response = json.dumps({"title": "Alpha", "content": "New content.", "tags": []})
    client = make_mock_client(mock_response)

    drafts, failed, _ = compile_concepts(config, client, db, concepts=["Alpha"])

    assert drafts == []
    assert failed == []
    assert client.generate.call_count == 0
    assert "User-reviewed draft body." in draft_path.read_text()
    state = db.get_compile_state("Alpha", "raw/a.md")
    assert state is not None
    assert state["status"] == "deferred_draft"


def test_compile_concepts_marks_sources_after_each_success(config, db):
    import json

    db.upsert_raw(RawNoteRecord(path="raw/a.md", content_hash="h1", status="ingested"))
    db.upsert_raw(RawNoteRecord(path="raw/b.md", content_hash="h2", status="ingested"))
    db.upsert_concepts("raw/a.md", ["Alpha"])
    db.upsert_concepts("raw/b.md", ["Beta"])
    (config.vault / "raw" / "a.md").write_text("---\ntitle: A\n---\nContent.")
    (config.vault / "raw" / "b.md").write_text("---\ntitle: B\n---\nContent.")

    client = make_mock_client()
    client.generate.side_effect = [
        json.dumps({"title": "Alpha", "content": "Alpha content.", "tags": []}),
        "not valid json",
        "not valid json",
        "not valid json",
    ]

    drafts, failed, _ = compile_concepts(config, client, db)

    assert len(drafts) == 1
    assert failed == ["Beta"]
    assert db.get_raw("raw/a.md").status == "compiled"
    assert db.get_raw("raw/b.md").status == "ingested"


def test_compile_concepts_mixed_source_failure_keeps_only_failed_concept_queued(config, db):
    import json

    db.upsert_raw(RawNoteRecord(path="raw/a.md", content_hash="h1", status="ingested"))
    db.upsert_raw(RawNoteRecord(path="raw/b.md", content_hash="h2", status="ingested"))
    db.upsert_concepts("raw/a.md", ["Alpha", "Beta"])
    db.upsert_concepts("raw/b.md", ["Beta"])
    (config.vault / "raw" / "a.md").write_text("---\ntitle: A\n---\nContent A.")
    (config.vault / "raw" / "b.md").write_text("---\ntitle: B\n---\nContent B.")

    client = make_mock_client()
    client.generate.side_effect = [
        json.dumps({"title": "Alpha", "content": "Alpha content.", "tags": []}),
        "not valid json",
        "not valid json",
        "not valid json",
    ]

    drafts, failed, _ = compile_concepts(config, client, db, concepts=["Alpha", "Beta"])

    assert len(drafts) == 1
    assert failed == ["Beta"]
    assert db.get_compile_state("Alpha", "raw/a.md")["status"] == "compiled"
    assert db.get_compile_state("Beta", "raw/a.md")["status"] == "failed"
    assert db.get_compile_state("Beta", "raw/b.md")["status"] == "failed"
    assert db.get_raw("raw/a.md").status == "ingested"
    assert db.get_raw("raw/b.md").status == "ingested"
    assert db.concepts_needing_compile() == ["Beta"]


def test_compile_concepts_force_clears_manual_edit_defer(config, db):
    import json

    db.upsert_raw(RawNoteRecord(path="raw/a.md", content_hash="h1", status="ingested"))
    db.upsert_concepts("raw/a.md", ["Alpha"])
    (config.vault / "raw" / "a.md").write_text("---\ntitle: A\n---\nContent.")
    wiki_path = config.wiki_dir / "Alpha.md"
    wiki_path.write_text("---\ntitle: Alpha\n---\nEdited.")
    db.upsert_article(
        WikiArticleRecord(
            path=str(wiki_path.relative_to(config.vault)),
            title="Alpha",
            sources=["raw/a.md"],
            content_hash="old-hash",
            status="published",
        )
    )

    client = make_mock_client(json.dumps({"title": "Alpha", "content": "New.", "tags": []}))

    drafts, failed, _ = compile_concepts(config, client, db)
    assert drafts == []
    assert failed == []
    assert db.get_compile_state("Alpha", "raw/a.md")["status"] == "deferred_manual_edit"

    drafts, failed, _ = compile_concepts(config, client, db, force=True, concepts=["Alpha"])
    assert len(drafts) == 1
    assert failed == []
    assert db.get_compile_state("Alpha", "raw/a.md")["status"] == "compiled"


def test_approve_and_reject_update_compile_state(config, db):
    import frontmatter as fm_lib

    from synto.vault import atomic_write

    db.upsert_raw(RawNoteRecord(path="raw/a.md", content_hash="h1", status="ingested"))
    db.upsert_concepts("raw/a.md", ["Alpha"])
    draft_path = config.drafts_dir / "Alpha.md"
    meta = {"title": "Alpha", "status": "draft", "tags": [], "sources": ["raw/a.md"]}
    atomic_write(draft_path, fm_lib.dumps(fm_lib.Post("Body.", **meta)))
    db.upsert_article(
        WikiArticleRecord(
            path=str(draft_path.relative_to(config.vault)),
            title="Alpha",
            sources=["raw/a.md"],
            content_hash="h",
            status="draft",
        )
    )
    db.mark_concept_compile_state("Alpha", ["raw/a.md"], "deferred_draft")

    approve_drafts(config, db, [draft_path])
    assert db.get_compile_state("Alpha", "raw/a.md")["status"] == "compiled"

    draft_path = config.drafts_dir / "Alpha.md"
    atomic_write(draft_path, fm_lib.dumps(fm_lib.Post("Body.", **meta)))
    db.upsert_article(
        WikiArticleRecord(
            path=str(draft_path.relative_to(config.vault)),
            title="Alpha",
            sources=["raw/a.md"],
            content_hash="h2",
            status="draft",
        )
    )
    reject_draft(draft_path, config, db, feedback="Nope")
    assert db.get_compile_state("Alpha", "raw/a.md")["status"] == "pending"


# ── Approval records approved_at ─────────────────────────────────────────────


def test_approve_drafts_sets_approved_at(config, db):
    import frontmatter as fm_lib

    from synto.vault import atomic_write

    draft_path = config.drafts_dir / "Article.md"
    meta = {"title": "Article", "status": "draft", "tags": [], "sources": [], "confidence": 0.7}
    atomic_write(draft_path, fm_lib.dumps(fm_lib.Post("## Body\n\nContent.", **meta)))
    db.upsert_article(
        WikiArticleRecord(
            path=str(draft_path.relative_to(config.vault)),
            title="Article",
            sources=[],
            content_hash="h",
            status="draft",
        )
    )

    published = approve_drafts(config, db, [draft_path])
    assert len(published) == 1
    art = db.get_article(str(published[0].relative_to(config.vault)))
    assert art is not None
    assert art.approved_at is not None


def test_approve_drafts_skips_paths_outside_drafts(config, db):
    outside = config.vault / "elsewhere.md"
    outside.write_text("---\ntitle: Elsewhere\nstatus: draft\n---\nBody.")

    published = approve_drafts(config, db, [outside])

    assert published == []
    assert outside.exists()


def test_approve_drafts_records_untracked_on_disk_draft(config, db):
    import frontmatter as fm_lib

    from synto.vault import atomic_write

    draft_path = config.drafts_dir / "Untracked.md"
    meta = {"title": "Untracked", "status": "draft", "tags": [], "sources": ["raw/a.md"]}
    atomic_write(draft_path, fm_lib.dumps(fm_lib.Post("Body.", **meta)))

    published = approve_drafts(config, db, [draft_path])

    assert len(published) == 1
    art = db.get_article("wiki/Untracked.md")
    assert art is not None
    assert art.title == "Untracked"
    assert art.is_draft is False


# ── _gather_sources ───────────────────────────────────────────────────────────


def test_gather_sources_missing_file_skipped(vault):
    """Source path that doesn't exist → skipped, no crash."""
    text, resolved = _gather_sources(["raw/nonexistent.md"], vault)
    assert text == ""
    assert resolved == []


def test_gather_sources_unreadable_file_skipped(vault):
    """Source file that can't be parsed → skipped, no crash."""
    bad = vault / "raw" / "bad.md"
    bad.write_bytes(b"\xff\xfe")  # invalid UTF-8 triggers parse error
    text, resolved = _gather_sources(["raw/bad.md"], vault)
    # May or may not resolve depending on parse_note tolerance — just no exception
    assert isinstance(text, str)
    assert isinstance(resolved, list)


def test_gather_sources_combines_multiple(vault):
    (vault / "raw" / "a.md").write_text("---\ntitle: A\n---\nContent A.")
    (vault / "raw" / "b.md").write_text("---\ntitle: B\n---\nContent B.")
    text, resolved = _gather_sources(["raw/a.md", "raw/b.md"], vault)
    assert "Content A." in text
    assert "Content B." in text
    assert len(resolved) == 2


def test_gather_sources_bare_filename_resolved(vault):
    """Model sometimes returns bare filename without raw/ prefix."""
    (vault / "raw" / "note.md").write_text("---\ntitle: Note\n---\nBody.")
    text, resolved = _gather_sources(["note.md"], vault)
    assert "Body." in text
    assert len(resolved) == 1


# ── Stub compile path ─────────────────────────────────────────────────────────


def test_compile_concepts_stub_produces_draft(config, db):
    """Stub concept → fast model called → draft created → stub removed from DB."""
    import json

    db.add_stub("Orphan Topic")
    mock_response = json.dumps({"title": "Orphan Topic", "content": "Stub content.", "tags": []})
    client = make_mock_client(mock_response)

    drafts, failed, _ = compile_concepts(config, client, db)
    assert len(drafts) == 1
    assert not db.has_stub("Orphan Topic")
    assert "Orphan" in drafts[0].name or "orphan" in drafts[0].name.lower()


def test_compile_concepts_stub_failure_adds_to_failed(config, db):
    """StructuredOutputError during stub compile → concept added to failed."""

    db.add_stub("Bad Stub")
    client = make_mock_client("not valid json at all {{{")
    # structured_output will exhaust retries and raise StructuredOutputError
    # Mock client to always return garbage
    client.generate.return_value = "garbage"

    drafts, failed, _ = compile_concepts(config, client, db)
    assert "Bad Stub" in failed


def test_compile_concepts_stub_llm_bad_request_adds_to_failed(config, db):
    """LLMBadRequestError during stub compile → concept in failed, no crash."""
    from synto.openai_compat_client import LLMBadRequestError

    db.add_stub("Context Overflow Stub")
    client = make_mock_client()
    client.generate.side_effect = LLMBadRequestError("HTTP 400: context too long")

    drafts, failed, _ = compile_concepts(config, client, db)
    assert "Context Overflow Stub" in failed
    assert drafts == []


def test_compile_concepts_article_llm_bad_request_adds_to_failed(config, db):
    """LLMBadRequestError during article compile → concept in failed, no crash."""
    from synto.openai_compat_client import LLMBadRequestError

    db.upsert_raw(RawNoteRecord(path="raw/src.md", content_hash="h1", status="ingested"))
    db.upsert_concepts("raw/src.md", ["Heavy Concept"])
    (config.vault / "raw" / "src.md").write_text(
        "---\ntitle: Source\n---\nContent about Heavy Concept."
    )

    client = make_mock_client()
    client.generate.side_effect = LLMBadRequestError("HTTP 400: n_keep > ctx")

    drafts, failed, _ = compile_concepts(config, client, db)
    assert "Heavy Concept" in failed
    assert drafts == []


def test_compile_concepts_retries_with_smaller_source_budget_on_context_overflow(
    config, db, caplog
):
    """Provider prompt-overflow errors should retry once with less source text."""
    from synto.openai_compat_client import LLMBadRequestError

    db.upsert_raw(RawNoteRecord(path="raw/src.md", content_hash="h1", status="ingested"))
    db.upsert_concepts("raw/src.md", ["Heavy Concept"])
    (config.vault / "raw" / "src.md").write_text(
        "---\ntitle: Source\n---\n" + ("Content about Heavy Concept. " * 500),
        encoding="utf-8",
    )

    mock_response = (
        '{"title":"Heavy Concept","tags":["heavy-concept"],'
        '"content":"Body","sources":["raw/src.md"]}'
    )
    client = make_mock_client(mock_response)
    overflow_error = LLMBadRequestError(
        "HTTP 400: The number of tokens to keep from the initial prompt "
        "is greater than the context length"
    )
    client.generate.side_effect = [
        overflow_error,
        mock_response,
    ]

    drafts, failed, _ = compile_concepts(config, client, db)

    assert failed == []
    assert len(drafts) == 1
    assert client.generate.call_count >= 2
    draft_text = drafts[0].read_text(encoding="utf-8")
    assert "prompt degraded to fit provider context" in draft_text
    assert "Compiled 'Heavy Concept' with reduced prompt context" in caplog.text


def test_compile_concepts_retry_value_error_is_counted_as_context_too_large(
    config, db, caplog, monkeypatch
):
    """Retry budget failures should preserve the context_too_large category."""
    from synto.openai_compat_client import LLMBadRequestError
    from synto.pipeline import compile as compile_module

    db.upsert_raw(RawNoteRecord(path="raw/src.md", content_hash="h1", status="ingested"))
    db.upsert_concepts("raw/src.md", ["Heavy Concept"])
    (config.vault / "raw" / "src.md").write_text(
        "---\ntitle: Source\n---\n" + ("Content about Heavy Concept. " * 500),
        encoding="utf-8",
    )

    overflow_error = LLMBadRequestError(
        "HTTP 400: The number of tokens to keep from the initial prompt "
        "is greater than the context length"
    )
    client = make_mock_client()
    client.generate.side_effect = [overflow_error]

    num_predict_calls = iter(
        [
            1024,
            ValueError(
                "Source content too large for heavy_ctx=8192: prompt ~9000 tokens leaves only 0"
            ),
            ValueError(
                "Source content too large for heavy_ctx=8192: prompt ~9000 tokens leaves only 0"
            ),
            ValueError(
                "Source content too large for heavy_ctx=8192: prompt ~9000 tokens leaves only 0"
            ),
            ValueError(
                "Source content too large for heavy_ctx=8192: prompt ~9000 tokens leaves only 0"
            ),
        ]
    )

    def fake_article_num_predict(_config, _prompt, _system, heavy_ctx=None):
        result = next(num_predict_calls)
        if isinstance(result, Exception):
            raise result
        return result

    monkeypatch.setattr(compile_module, "_article_num_predict", fake_article_num_predict)

    drafts, failed, _ = compile_concepts(config, client, db)

    assert drafts == []
    assert failed == ["Heavy Concept"]
    assert "Compile failures by category: 1 context_too_large" in caplog.text
    assert "Compile failures by category: 1 other" not in caplog.text


def test_compile_concepts_normal_success_has_no_prompt_degraded_annotation(config, db):
    db.upsert_raw(RawNoteRecord(path="raw/src.md", content_hash="h1", status="ingested"))
    db.upsert_concepts("raw/src.md", ["Normal Concept"])
    (config.vault / "raw" / "src.md").write_text(
        "---\ntitle: Source\n---\nContent about Normal Concept.",
        encoding="utf-8",
    )

    mock_response = (
        '{"title":"Normal Concept","tags":["normal-concept"],'
        '"content":"Body","sources":["raw/src.md"]}'
    )
    client = make_mock_client(mock_response)

    drafts, failed, _ = compile_concepts(config, client, db)

    assert failed == []
    assert len(drafts) == 1
    draft_text = drafts[0].read_text(encoding="utf-8")
    assert "prompt degraded to fit provider context" not in draft_text
